import { useEffect, useRef, useState, type PointerEvent } from "react";
import { ChevronLeft, ChevronRight, Coins, Flag, Pause, Play, RotateCcw, Swords } from "lucide-react";
import { LEVELS } from "@/game/levels";
import { Session, type Hud, type Phase } from "@/game/session";

const GAME_KEYS = new Set([
  "ArrowLeft",
  "ArrowRight",
  "ArrowUp",
  "ArrowDown",
  "Space",
  "KeyA",
  "KeyD",
  "KeyW",
]);

function clock(t: number) {
  const s = Math.max(0, Math.floor(t));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

const INITIAL: Hud = {
  phase: "title",
  levelId: "faroles",
  levelName: "Distrito de la Luna",
  coins: 0,
  total: 0,
  jumps: 2,
  time: 0,
  toast: "",
};

export function GameScreen() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<Session | null>(null);
  const [hud, setHud] = useState<Hud>(INITIAL);
  const [bestTick, setBestTick] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const session = new Session();
    sessionRef.current = session;
    session.onChange = (next) => {
      setHud(next);
      setBestTick((n) => n + 1);
    };
    session.emit(true);

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) {
        if (GAME_KEYS.has(e.code) && session.phase === "play") e.preventDefault();
        return;
      }
      session.unlockAudio();
      if (e.code === "Escape" || e.code === "KeyP") {
        session.togglePause();
        e.preventDefault();
        return;
      }
      if (e.code === "KeyR" && (session.phase === "dead" || session.phase === "paused")) {
        if (session.phase === "dead") session.retry();
        else session.restartLevel();
        return;
      }
      session.keys.add(e.code);
      if (GAME_KEYS.has(e.code) && session.phase === "play") e.preventDefault();
    };
    const onKeyUp = (e: KeyboardEvent) => {
      session.keys.delete(e.code);
    };
    const clear = () => session.keys.clear();
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", clear);
    document.addEventListener("visibilitychange", clear);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      session.frame(dt);
      const ctx = canvas.getContext("2d");
      if (ctx) session.draw(ctx, canvas.clientWidth, canvas.clientHeight);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", clear);
      document.removeEventListener("visibilitychange", clear);
      session.onChange = null;
    };
  }, []);

  const phase: Phase = hud.phase;

  const hold = (flag: "left" | "right" | "jump") => ({
    onPointerDown: (e: PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      const live = sessionRef.current;
      if (!live) return;
      live.unlockAudio();
      e.currentTarget.setPointerCapture(e.pointerId);
      live.touch[flag] = true;
      if (flag === "jump") live.touch.jumpEdge = true;
    },
    onPointerUp: () => {
      const live = sessionRef.current;
      if (live) live.touch[flag] = false;
    },
    onPointerCancel: () => {
      const live = sessionRef.current;
      if (live) live.touch[flag] = false;
    },
    onLostPointerCapture: () => {
      const live = sessionRef.current;
      if (live) live.touch[flag] = false;
    },
  });

  return (
    <main
      className="relative h-dvh overflow-hidden bg-ink text-bone"
      onContextMenu={(e) => e.preventDefault()}
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      {phase === "play" || phase === "paused" || phase === "dead" || phase === "clear" ? (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-3 px-4 pt-4">
          <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-line bg-night/85 px-3 py-2 backdrop-blur-sm">
            <Coins className="size-4 text-gold" aria-hidden />
            <span className="text-sm font-semibold tracking-wide" aria-label={`Monedas ${hud.coins} de ${hud.total}`}>
              {hud.coins}
              <span className="text-mist">/{hud.total}</span>
            </span>
            <span className="ml-1 flex gap-1" aria-label={`Saltos ${hud.jumps}`}>
              {[0, 1].map((i) => (
                <span
                  key={i}
                  className={i < hud.jumps ? "size-2 rounded-full bg-violet" : "size-2 rounded-full bg-line"}
                />
              ))}
            </span>
          </div>
          <div className="pointer-events-none absolute top-20 left-1/2 z-20 -translate-x-1/2 text-center">
            <p className="font-display text-xs tracking-wide text-bone sm:text-sm sm:tracking-widest">{hud.toast || hud.levelName}</p>
            <p className="hidden text-xs text-mist sm:block">A D · Espacio · doble salto en el aire</p>
          </div>
          <span className="hidden sm:block" />
          {phase === "play" ? (
            <button
              type="button"
              className="pointer-events-auto grid size-11 place-items-center rounded-full border border-line bg-night/85 text-bone"
              aria-label="Pausa"
              onClick={() => sessionRef.current?.pause()}
            >
              <Pause className="size-5" />
            </button>
          ) : (
            <span className="size-11" />
          )}
        </div>
      ) : null}

      {phase === "title" ? (
        <div className="absolute inset-0 z-10 touch-pan-y overflow-y-auto bg-gradient-to-t from-ink via-ink/80 to-ink/20 md:bg-ink/25">
          <section className="safe-bottom mx-auto flex min-h-full w-full max-w-md flex-col justify-end px-5 pt-16 pb-6 md:justify-center">
            <div className="rounded-card border border-line bg-ink/88 p-5 md:p-6">
            <p className="flex items-center gap-2 text-xs font-semibold tracking-[0.22em] text-ember uppercase">
              <Swords className="size-4" aria-hidden />
              Mundo espiritual
            </p>
            <h1 className="font-display mt-2 text-4xl leading-none text-bone sm:text-5xl">
              Noche
              <span className="block">Shinigami</span>
            </h1>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-mist">
              Corre, salta y usa el doble salto. Cruza plataformas móviles, junta las monedas y evita púas y
              máscaras. El farol guarda tu punto de control. La bandera termina el nivel.
            </p>
            <button
              type="button"
              className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-full bg-ember font-semibold text-ink"
              onClick={() => sessionRef.current?.startLevel("faroles")}
            >
              <Play className="size-5" />
              Jugar
            </button>
            <ul className="mt-4 grid grid-cols-3 gap-2 text-center text-xs text-mist">
              <li className="rounded-card border border-line bg-night/70 px-2 py-2">
                <span className="block font-semibold text-bone">Correr</span>
                izquierda
              </li>
              <li className="rounded-card border border-line bg-night/70 px-2 py-2">
                <span className="block font-semibold text-bone">Doble salto</span>
                en el aire
              </li>
              <li className="rounded-card border border-line bg-night/70 px-2 py-2">
                <span className="block font-semibold text-bone">Meta</span>
                la bandera
              </li>
            </ul>
            <div className="mt-4 grid gap-2">
              {LEVELS.map((level, index) => {
                const mark = bestTick >= 0 ? sessionRef.current?.bestFor(level.id) : null;
                return (
                  <button
                    key={level.id}
                    type="button"
                    className="flex items-center justify-between gap-3 rounded-card border border-line bg-panel/80 px-4 py-3 text-left"
                    onClick={() => sessionRef.current?.startLevel(level.id)}
                  >
                    <span>
                      <span className="block text-sm font-semibold text-bone">
                        {index + 1}. {level.name}
                      </span>
                      <span className="mt-0.5 block text-xs text-mist">{level.blurb}</span>
                    </span>
                    <span className="shrink-0 text-right text-xs text-gold">
                      {mark ? (
                        <>
                          {mark.coins} monedas
                          <span className="block text-mist">{clock(mark.time)}</span>
                        </>
                      ) : (
                        <span className="text-mist">Nuevo</span>
                      )}
                    </span>
                  </button>
                );
              })}
            </div>
            </div>
          </section>
        </div>
      ) : null}

      {phase === "paused" || phase === "dead" || phase === "clear" ? (
        <div className="absolute inset-0 z-30 flex items-end justify-center bg-ink/55 sm:items-center">
          <section className="safe-bottom w-full max-w-md rounded-card border border-line bg-panel px-5 pt-6 pb-6 sm:mx-4">
            <p className="text-xs font-semibold tracking-[0.18em] text-ember uppercase">
              {phase === "clear" ? "Meta" : phase === "dead" ? "Caíste" : "Pausa"}
            </p>
            <h2 className="font-display mt-1 text-3xl text-bone">
              {phase === "clear" ? "Nivel completo" : phase === "dead" ? "Caíste" : hud.levelName}
            </h2>
            <p className="mt-2 text-sm text-mist">
              {phase === "clear"
                ? `Monedas ${hud.coins}/${hud.total} · ${clock(hud.time)}`
                : phase === "dead"
                  ? "Reintentar te deja en el último farol. También puedes reiniciar el nivel o elegir otro."
                  : "El distrito espera."}
            </p>
            <div className="mt-5 grid gap-2">
              {phase === "dead" ? (
                <button
                  type="button"
                  className="flex h-12 items-center justify-center gap-2 rounded-full bg-ember font-semibold text-ink"
                  onClick={() => sessionRef.current?.retry()}
                >
                  <RotateCcw className="size-5" />
                  Reintentar
                </button>
              ) : null}
              {phase === "paused" ? (
                <button
                  type="button"
                  className="flex h-12 items-center justify-center gap-2 rounded-full bg-ember font-semibold text-ink"
                  onClick={() => sessionRef.current?.resume()}
                >
                  <Play className="size-5" />
                  Continuar
                </button>
              ) : null}
              {phase === "clear" ? (
                <button
                  type="button"
                  className="flex h-12 items-center justify-center gap-2 rounded-full bg-ember font-semibold text-ink"
                  onClick={() => sessionRef.current?.nextLevel()}
                >
                  <Flag className="size-5" />
                  {hud.levelId === "torre" ? "Volver al inicio" : "Siguiente nivel"}
                </button>
              ) : null}
              {phase !== "clear" ? (
                <button
                  type="button"
                  className="flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-night font-semibold text-bone"
                  onClick={() => sessionRef.current?.restartLevel()}
                >
                  <RotateCcw className="size-5" />
                  Reiniciar nivel
                </button>
              ) : null}
              <button
                type="button"
                className="flex h-12 items-center justify-center rounded-full border border-line font-semibold text-mist"
                onClick={() => sessionRef.current?.toTitle()}
              >
                Elegir nivel
              </button>
            </div>
          </section>
        </div>
      ) : null}

      {phase === "play" ? (
        <div className="safe-bottom pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between px-4 pb-4">
          <div className="pointer-events-auto flex gap-3">
            <button
              type="button"
              aria-label="Izquierda"
              className="grid size-16 place-items-center rounded-full border border-line bg-night/80 text-bone active:bg-ember active:text-ink"
              {...hold("left")}
            >
              <ChevronLeft className="size-7" />
            </button>
            <button
              type="button"
              aria-label="Derecha"
              className="grid size-16 place-items-center rounded-full border border-line bg-night/80 text-bone active:bg-ember active:text-ink"
              {...hold("right")}
            >
              <ChevronRight className="size-7" />
            </button>
          </div>
          <button
            type="button"
            aria-label="Saltar"
            className="pointer-events-auto grid size-20 place-items-center rounded-full border border-ember bg-ember/90 font-display text-sm leading-tight tracking-wide text-ink active:bg-gold"
            {...hold("jump")}
          >
            Salto
          </button>
        </div>
      ) : null}
    </main>
  );
}
