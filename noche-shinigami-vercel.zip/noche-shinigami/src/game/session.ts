import {
  TILE,
  levelById,
  type Enemy,
  type Level,
  type LevelId,
  type Mover,
} from "./levels";

export type Phase = "title" | "play" | "dead" | "clear" | "paused";

export type Hud = {
  phase: Phase;
  levelId: LevelId;
  levelName: string;
  coins: number;
  total: number;
  jumps: number;
  time: number;
  toast: string;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
};

type Best = { coins: number; time: number };

const SAVE_KEY = "noche-shinigami-v1";
const VIEW_W = 560;
const PW = 26;
const PH = 46;
const SPEED = 255;
const ACC_G = 2400;
const ACC_A = 1500;
const GRAV_RISE = 1250;
const GRAV_FALL = 2750;
const GRAV_APEX = 680;
const JUMP = -500;
const DJUMP = -445;
const TERMINAL = 860;
const COYOTE = 0.11;
const BUFFER = 0.13;
const STEP = 1 / 60;

const HERO_FOOT = 117 / 128;
const MASK_FOOT = 116 / 128;

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function approach(v: number, target: number, delta: number) {
  if (v < target) return Math.min(target, v + delta);
  return Math.max(target, v - delta);
}

function overlap(
  ax: number,
  ay: number,
  aw: number,
  ah: number,
  bx: number,
  by: number,
  bw: number,
  bh: number,
) {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

function loadImage(src: string) {
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = src;
  return img;
}

function loadSave(): Record<string, Best> {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as { best?: Record<string, Best> };
    return parsed.best ?? {};
  } catch {
    return {};
  }
}

export class Session {
  phase: Phase = "title";
  level: Level = levelById("faroles");
  keys = new Set<string>();
  touch = { left: false, right: false, jump: false, jumpEdge: false };
  px = 0;
  py = 0;
  vx = 0;
  vy = 0;
  facing = 1;
  grounded = false;
  jumpsLeft = 1;
  coyote = 0;
  buffer = 0;
  rising = false;
  cut = false;
  riding: number | null = null;
  collected = new Set<string>();
  spawn = { x: 0, y: 0 };
  checkpointId = "spawn";
  enemies: Enemy[] = [];
  time = 0;
  levelTime = 0;
  anim = 0;
  land = 0;
  grace = 0;
  shake = 0;
  toast = "";
  toastT = 0;
  camX = 0;
  camY = 0;
  acc = 0;
  wasJump = false;
  wasPad = false;
  best: Record<string, Best> = {};
  particles: Particle[] = [];
  onChange: ((hud: Hud) => void) | null = null;
  private audio: AudioContext | null = null;
  private lastHud = "";
  private images: {
    idle: HTMLImageElement[];
    run: HTMLImageElement[];
    jump: HTMLImageElement[];
    mask: HTMLImageElement[];
    orb: HTMLImageElement[];
    flag: HTMLImageElement;
    lantern: HTMLImageElement;
    spikes: HTMLImageElement;
    tile: HTMLImageElement;
    bg: HTMLImageElement;
  };

  constructor() {
    const frames = (dir: string, prefix: string, n: number) =>
      Array.from({ length: n }, (_, i) => loadImage(`/sprites/${dir}/${prefix}-${i + 1}.png`));
    this.images = {
      idle: frames("hero-idle", "idle", 4),
      run: frames("hero-run", "run", 4),
      jump: frames("hero-jump", "jump", 4),
      mask: frames("mask", "walk", 4),
      orb: frames("orb", "fx", 4),
      flag: loadImage("/sprites/flag/clean.png"),
      lantern: loadImage("/sprites/lantern/clean.png"),
      spikes: loadImage("/sprites/spikes/clean.png"),
      tile: loadImage("/sprites/tile.jpg"),
      bg: loadImage("/sprites/bg.jpg"),
    };
    this.best = loadSave();
    this.resetLevel(this.level, false);
    this.expose();
  }

  expose() {
    window.__controlsTest = {
      getX: () => this.px,
      getY: () => this.py,
      getSpeed: () => this.vx,
      getYaw: () => 0,
      setKeys: (codes: string[]) => {
        this.keys = new Set(codes);
        this.touch.left = false;
        this.touch.right = false;
        this.touch.jump = false;
      },
    };
  }

  unlockAudio() {
    if (!this.audio) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      this.audio = new Ctx();
    }
    if (this.audio.state === "suspended") void this.audio.resume();
  }

  private tone(freq: number, dur: number, type: OscillatorType, gain: number, slide = 0) {
    if (!this.audio) return;
    const t = this.audio.currentTime;
    const osc = this.audio.createOscillator();
    const amp = this.audio.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    amp.gain.setValueAtTime(gain, t);
    amp.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(amp);
    amp.connect(this.audio.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  hud(): Hud {
    return {
      phase: this.phase,
      levelId: this.level.id,
      levelName: this.level.name,
      coins: this.collected.size,
      total: this.level.coins.length,
      jumps: this.grounded ? 2 : this.jumpsLeft,
      time: this.levelTime,
      toast: this.toastT > 0 ? this.toast : "",
    };
  }

  emit(force = false) {
    const hud = this.hud();
    const key = `${hud.phase}|${hud.coins}|${hud.jumps}|${hud.toast}|${hud.levelId}|${Math.floor(hud.time * 4)}`;
    if (!force && key === this.lastHud) return;
    this.lastHud = key;
    this.onChange?.(hud);
  }

  bestFor(id: LevelId) {
    return this.best[id] ?? null;
  }

  startLevel(id: LevelId) {
    this.unlockAudio();
    this.level = levelById(id);
    this.resetLevel(this.level, true);
    this.phase = "play";
    this.tone(220, 0.08, "square", 0.04);
    this.emit(true);
  }

  resume() {
    if (this.phase === "paused") {
      this.phase = "play";
      this.emit(true);
    }
  }

  pause() {
    if (this.phase === "play") {
      this.phase = "paused";
      this.keys.clear();
      this.emit(true);
    }
  }

  togglePause() {
    if (this.phase === "play") this.pause();
    else if (this.phase === "paused") this.resume();
  }

  toTitle() {
    this.phase = "title";
    this.keys.clear();
    this.emit(true);
  }

  retry() {
    this.px = this.spawn.x;
    this.py = this.spawn.y - PH;
    this.vx = 0;
    this.vy = 0;
    this.grounded = false;
    this.jumpsLeft = 1;
    this.coyote = 0;
    this.buffer = 0;
    this.rising = false;
    this.riding = null;
    this.grace = 0.7;
    this.phase = "play";
    this.snapCamera();
    this.emit(true);
  }

  restartLevel() {
    this.resetLevel(this.level, true);
    this.phase = "play";
    this.emit(true);
  }

  nextLevel() {
    const order: LevelId[] = ["faroles", "puente", "torre"];
    const i = order.indexOf(this.level.id);
    this.startLevel(order[(i + 1) % order.length]);
  }

  private resetLevel(level: Level, snap: boolean) {
    this.level = level;
    this.spawn = { x: level.spawn.x, y: level.spawn.y };
    this.checkpointId = "spawn";
    this.collected = new Set();
    this.px = level.spawn.x;
    this.py = level.spawn.y - PH;
    this.vx = 0;
    this.vy = 0;
    this.facing = 1;
    this.grounded = false;
    this.jumpsLeft = 1;
    this.coyote = COYOTE;
    this.buffer = 0;
    this.rising = false;
    this.cut = false;
    this.riding = null;
    this.enemies = level.enemies.map((e) => ({ ...e }));
    this.levelTime = 0;
    this.grace = 0.4;
    this.particles = [];
    this.land = 0;
    if (snap) this.snapCamera();
    else {
      this.camX = 0;
      this.camY = Math.max(0, level.spawn.y - 280);
    }
  }

  private snapCamera() {
    const view = this.viewSize();
    this.camX = clamp(this.px + PW / 2 - view.w * 0.4, 0, Math.max(0, this.level.width - view.w));
    this.camY = clamp(this.py + PH / 2 - view.h * 0.62, 0, Math.max(0, this.level.height - view.h));
  }

  private viewSize() {
    const canvas = document.querySelector("canvas");
    const cssW = canvas?.clientWidth || 390;
    const cssH = canvas?.clientHeight || 700;
    const w = VIEW_W;
    const h = VIEW_W * (cssH / Math.max(1, cssW));
    return { w, h, cssW, cssH };
  }

  frame(dt: number) {
    this.time += dt;
    if (this.toastT > 0) this.toastT = Math.max(0, this.toastT - dt);
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 18);
    if (this.land > 0) this.land = Math.max(0, this.land - dt);

    if (this.phase === "play") {
      this.levelTime += dt;
      this.sampleJumpEdge();
      this.acc += Math.min(dt, 0.1);
      let guard = 0;
      while (this.acc >= STEP && guard < 5) {
        this.sim(STEP);
        this.buffer = Math.max(0, this.buffer - STEP);
        if (!this.grounded) this.coyote = Math.max(0, this.coyote - STEP);
        this.acc -= STEP;
        guard++;
      }
      this.anim += dt;
      this.updateDecor(dt);
      this.pickups();
    } else if (this.phase === "title" || this.phase === "paused" || this.phase === "clear") {
      this.anim += dt;
    }

    for (const p of this.particles) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += 500 * dt;
    }
    this.particles = this.particles.filter((p) => p.life > 0);

    this.followCamera(dt);
    this.emit();
  }

  private sampleJumpEdge() {
    const held =
      this.touch.jump ||
      this.keys.has("Space") ||
      this.keys.has("KeyW") ||
      this.keys.has("ArrowUp");
    let padJump = false;
    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (pad && (pad.buttons[0]?.pressed || pad.buttons[1]?.pressed)) padJump = true;
    }
    if ((held && !this.wasJump) || this.touch.jumpEdge || (padJump && !this.wasPad)) {
      this.buffer = BUFFER;
    }
    this.touch.jumpEdge = false;
    this.wasJump = held;
    this.wasPad = padJump;
  }

  private moveX() {
    let x = 0;
    if (this.touch.left || this.keys.has("KeyA") || this.keys.has("ArrowLeft")) x -= 1;
    if (this.touch.right || this.keys.has("KeyD") || this.keys.has("ArrowRight")) x += 1;
    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (!pad) continue;
      const ax = pad.axes[0] ?? 0;
      if (Math.abs(ax) > 0.2) x = clamp(ax, -1, 1);
      if (pad.buttons[0]?.pressed || pad.buttons[14]?.pressed) {
        /* jump polled below */
      }
      if (pad.buttons[14]?.pressed) x -= 1;
      if (pad.buttons[15]?.pressed) x += 1;
    }
    return clamp(x, -1, 1);
  }

  private jumpHeld() {
    if (this.touch.jump || this.keys.has("Space") || this.keys.has("KeyW") || this.keys.has("ArrowUp")) {
      return true;
    }
    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (pad && (pad.buttons[0]?.pressed || pad.buttons[1]?.pressed)) return true;
    }
    return false;
  }

  private sim(dt: number) {
    const move = this.moveX();
    if (move < -0.1) this.facing = -1;
    else if (move > 0.1) this.facing = 1;

    if (this.riding !== null) {
      const m = this.level.movers[this.riding];
      const now = this.moverPos(m, this.time);
      const prev = this.moverPos(m, this.time - dt);
      this.px += now.x - prev.x;
      this.py += now.y - prev.y;
    }

    const accel = (this.grounded ? ACC_G : ACC_A) * dt;
    this.vx = approach(this.vx, move * SPEED, accel);

    if (!this.jumpHeld() && this.vy < 0 && this.rising && !this.cut) {
      this.vy *= 0.48;
      this.cut = true;
    }

    this.px += this.vx * dt;
    this.resolveX();

    let g = GRAV_FALL;
    if (this.vy < 0 && this.jumpHeld() && this.rising) g = GRAV_RISE;
    else if (Math.abs(this.vy) < 90) g = GRAV_APEX;
    this.vy = Math.min(TERMINAL, this.vy + g * dt);

    const prevBottom = this.py + PH;
    this.py += this.vy * dt;
    this.grounded = false;
    this.riding = null;
    this.resolveY(prevBottom);

    if (this.grounded) {
      this.coyote = COYOTE;
      this.jumpsLeft = 1;
      this.rising = false;
      this.cut = false;
    }

    this.tryJump();

    if (this.grace > 0) this.grace -= dt;
    else this.hazards();

    if (this.py > this.level.height + 30) this.die();
  }

  private tryJump() {
    if (this.buffer <= 0) return;
    if (this.grounded || this.coyote > 0) {
      this.vy = JUMP;
      this.grounded = false;
      this.coyote = 0;
      this.buffer = 0;
      this.jumpsLeft = 1;
      this.rising = true;
      this.cut = false;
      this.riding = null;
      this.tone(420, 0.09, "square", 0.05, 180);
      this.burst(this.px + PW / 2, this.py + PH, "#efe6d6", 4);
      return;
    }
    if (this.jumpsLeft > 0) {
      this.vy = DJUMP;
      this.jumpsLeft = 0;
      this.buffer = 0;
      this.rising = true;
      this.cut = false;
      this.tone(620, 0.1, "triangle", 0.05, 240);
      this.burst(this.px + PW / 2, this.py + PH * 0.4, "#7c5cbf", 7);
    }
  }

  private solidAt(tx: number, ty: number) {
    const row = this.level.grid[ty];
    if (!row) return false;
    return row[tx] === "#";
  }

  private resolveX() {
    const top = Math.floor((this.py + 10) / TILE);
    const bot = Math.floor((this.py + PH - 12) / TILE);
    for (let guard = 0; guard < 4; guard++) {
      const left = Math.floor(this.px / TILE);
      const right = Math.floor((this.px + PW - 0.01) / TILE);
      let hit = false;
      for (let ty = top; ty <= bot && !hit; ty++) {
        for (let tx = left; tx <= right; tx++) {
          if (!this.solidAt(tx, ty)) continue;
          const tileLeft = tx * TILE;
          const tileRight = tileLeft + TILE;
          const penL = this.px + PW - tileLeft;
          const penR = tileRight - this.px;
          if (penL <= 0 || penR <= 0) continue;
          if (this.vx > 0 || (this.vx === 0 && penL <= penR)) {
            this.px -= penL + 0.02;
            this.vx = Math.min(0, this.vx);
          } else {
            this.px += penR + 0.02;
            this.vx = Math.max(0, this.vx);
          }
          hit = true;
          break;
        }
      }
      if (!hit) break;
    }
  }

  private resolveY(prevBottom: number) {
    const left = Math.floor((this.px + 4) / TILE);
    const right = Math.floor((this.px + PW - 4) / TILE);
    const top = Math.floor(this.py / TILE);
    const bot = Math.floor((this.py + PH - 0.01) / TILE);

    if (this.vy >= 0) {
      let floor = Infinity;
      for (let ty = top; ty <= bot; ty++) {
        for (let tx = left; tx <= right; tx++) {
          if (!this.solidAt(tx, ty)) continue;
          const tileTop = ty * TILE;
          if (prevBottom <= tileTop + 3) floor = Math.min(floor, tileTop);
        }
      }
      for (let ty = top; ty <= bot; ty++) {
        for (let tx = left; tx <= right; tx++) {
          const row = this.level.grid[ty];
          if (!row || row[tx] !== "=") continue;
          const tileTop = ty * TILE;
          if (prevBottom <= tileTop + 3 && this.py + PH >= tileTop) floor = Math.min(floor, tileTop);
        }
      }
      const moverFloor = this.moverFloor(prevBottom);
      if (moverFloor !== null) floor = Math.min(floor, moverFloor);
      if (floor !== Infinity) {
        const landed = !this.grounded && this.vy > 280;
        this.py = floor - PH;
        this.vy = 0;
        this.grounded = true;
        if (landed) {
          this.land = 0.12;
          this.shake = Math.max(this.shake, 1.2);
        }
      }
    } else {
      let ceil = -Infinity;
      for (let ty = top; ty <= bot; ty++) {
        for (let tx = left; tx <= right; tx++) {
          if (!this.solidAt(tx, ty)) continue;
          const tileBottom = ty * TILE + TILE;
          if (this.py <= tileBottom && prevBottom - PH >= tileBottom - 2) {
            ceil = Math.max(ceil, tileBottom);
          }
        }
      }
      if (ceil !== -Infinity) {
        this.py = ceil + 0.01;
        this.vy = 0;
        this.rising = false;
      }
    }
  }

  private moverPos(m: Mover, time: number) {
    const s = Math.sin((time * Math.PI * 2) / m.period + m.phase);
    return {
      x: m.axis === "x" ? m.ox + s * m.amp : m.ox,
      y: m.axis === "y" ? m.oy + s * m.amp : m.oy,
    };
  }

  private moverFloor(prevBottom: number) {
    let best: number | null = null;
    this.level.movers.forEach((m, i) => {
      const pos = this.moverPos(m, this.time);
      const xOverlap = this.px + PW - 2 > pos.x && this.px + 2 < pos.x + m.w;
      if (!xOverlap) return;
      if (prevBottom <= pos.y + 8 && this.py + PH >= pos.y && this.vy >= -20) {
        if (best === null || pos.y < best) {
          best = pos.y;
          this.riding = i;
        }
      }
    });
    return best;
  }

  private updateDecor(dt: number) {
    for (const e of this.enemies) {
      e.x += e.dir * 72 * dt;
      if (e.x < e.minX) {
        e.x = e.minX;
        e.dir = 1;
      } else if (e.x > e.maxX) {
        e.x = e.maxX;
        e.dir = -1;
      }
    }
    if (Math.abs(this.vx) > 40 && this.grounded && Math.random() < dt * 8) {
      this.particles.push({
        x: this.px + PW / 2,
        y: this.py + PH,
        vx: -this.facing * 20,
        vy: -30,
        life: 0.35,
        max: 0.35,
        color: "#efe6d6",
        size: 3,
      });
    }
  }

  private pickups() {
    const box = { x: this.px - 2, y: this.py - 2, w: PW + 4, h: PH + 4 };
    for (const coin of this.level.coins) {
      if (this.collected.has(coin.id)) continue;
      if (overlap(box.x, box.y, box.w, box.h, coin.x - 12, coin.y - 12, 24, 24)) {
        this.collected.add(coin.id);
        this.tone(880, 0.07, "square", 0.045, 200);
        this.burst(coin.x, coin.y, "#e6c15a", 6);
        this.emit(true);
      }
    }
    for (const cp of this.level.checkpoints) {
      if (this.checkpointId === cp.id) continue;
      if (overlap(this.px, this.py, PW, PH, cp.x - 18, cp.y - 56, 36, 56)) {
        this.checkpointId = cp.id;
        this.spawn = { x: cp.x - PW / 2, y: cp.y };
        this.toast = "Punto de control";
        this.toastT = 1.5;
        this.tone(300, 0.12, "triangle", 0.05, 80);
        this.emit(true);
      }
    }
    const flag = this.level.flag;
    if (overlap(this.px, this.py, PW, PH, flag.x - 16, flag.y - 78, 32, 78)) {
      this.win();
    }
  }

  private hazards() {
    const left = Math.floor(this.px / TILE);
    const right = Math.floor((this.px + PW) / TILE);
    const top = Math.floor(this.py / TILE);
    const bot = Math.floor((this.py + PH) / TILE);
    for (let ty = top; ty <= bot; ty++) {
      for (let tx = left; tx <= right; tx++) {
        if (this.level.grid[ty]?.[tx] !== "^") continue;
        const sx = tx * TILE + 8;
        const sy = ty * TILE + 10;
        if (overlap(this.px, this.py, PW, PH, sx, sy, TILE - 16, TILE - 12)) {
          this.die();
          return;
        }
      }
    }
    for (const e of this.enemies) {
      if (overlap(this.px + 2, this.py + 4, PW - 4, PH - 6, e.x + 6, e.y + 6, e.w - 12, e.h - 8)) {
        this.die();
        return;
      }
    }
  }

  private die() {
    if (this.phase !== "play") return;
    this.phase = "dead";
    this.shake = 9;
    this.vx = 0;
    this.tone(110, 0.22, "sawtooth", 0.05, -70);
    this.burst(this.px + PW / 2, this.py + PH / 2, "#d1545c", 12);
    this.keys.clear();
    this.touch.left = false;
    this.touch.right = false;
    this.touch.jump = false;
    this.emit(true);
  }

  private win() {
    if (this.phase !== "play") return;
    this.phase = "clear";
    const prev = this.best[this.level.id];
    const coins = this.collected.size;
    const better =
      !prev || coins > prev.coins || (coins === prev.coins && this.levelTime < prev.time);
    if (better) {
      this.best[this.level.id] = { coins, time: this.levelTime };
      try {
        localStorage.setItem(SAVE_KEY, JSON.stringify({ best: this.best }));
      } catch {
        /* ignore quota */
      }
    }
    this.tone(523, 0.12, "triangle", 0.05);
    this.tone(659, 0.14, "triangle", 0.04);
    this.tone(784, 0.2, "square", 0.04);
    this.emit(true);
  }

  private burst(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 40 + Math.random() * 140;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - 40,
        life: 0.4 + Math.random() * 0.3,
        max: 0.7,
        color,
        size: 2 + Math.random() * 3,
      });
    }
  }

  private followCamera(dt: number) {
    const view = this.viewSize();
    const look = this.facing * 70;
    const targetX = this.px + PW / 2 - view.w / 2 + look;
    const targetY = this.py + PH / 2 - view.h * 0.46;
    const k = 1 - Math.exp(-dt * (this.phase === "play" ? 7 : 2));
    const maxX = Math.max(0, this.level.width - view.w);
    const maxY = Math.max(0, this.level.height - view.h);
    this.camX += (clamp(targetX, 0, maxX) - this.camX) * k;
    this.camY += (clamp(targetY, 0, maxY) - this.camY) * k;
  }

  draw(ctx: CanvasRenderingContext2D, cssW: number, cssH: number) {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const canvas = ctx.canvas;
    const bw = Math.max(1, Math.floor(cssW * dpr));
    const bh = Math.max(1, Math.floor(cssH * dpr));
    if (canvas.width !== bw || canvas.height !== bh) {
      canvas.width = bw;
      canvas.height = bh;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.fillStyle = "#070814";
    ctx.fillRect(0, 0, cssW, cssH);

    const view = this.viewSize();
    const scale = cssW / view.w;
    const shakeX = this.shake ? (Math.random() - 0.5) * this.shake : 0;
    const shakeY = this.shake ? (Math.random() - 0.5) * this.shake : 0;
    const camX = Math.round(this.camX);
    const camY = Math.round(this.camY);

    this.drawBg(ctx, cssW, cssH, camX);

    ctx.save();
    ctx.translate(shakeX, shakeY);
    ctx.translate(-camX * scale, -camY * scale);
    ctx.scale(scale, scale);
    this.drawWorld(ctx);
    ctx.restore();

    if (this.phase === "dead") {
      ctx.fillStyle = "rgba(209, 84, 92, 0.18)";
      ctx.fillRect(0, 0, cssW, cssH);
    }
  }

  private drawBg(ctx: CanvasRenderingContext2D, cssW: number, cssH: number, camX: number) {
    const bg = this.images.bg;
    if (!bg.complete || !bg.naturalWidth) {
      ctx.fillStyle = "#14182e";
      ctx.fillRect(0, 0, cssW, cssH);
      return;
    }
    const scale = Math.max(cssW / bg.naturalWidth, cssH / bg.naturalHeight) * 1.08;
    const dw = bg.naturalWidth * scale;
    const dh = bg.naturalHeight * scale;
    const maxShift = Math.max(0, dw - cssW);
    const shift = clamp(camX * 0.18, 0, maxShift);
    ctx.drawImage(bg, -shift, (cssH - dh) * 0.35, dw, dh);
    ctx.fillStyle = "rgba(7, 8, 20, 0.38)";
    ctx.fillRect(0, 0, cssW, cssH);
  }

  private drawWorld(ctx: CanvasRenderingContext2D) {
    const tile = this.images.tile;
    const ready = tile.complete && tile.naturalWidth > 0;
    for (let y = 0; y < this.level.rows; y++) {
      const row = this.level.grid[y];
      for (let x = 0; x < this.level.cols; x++) {
        const ch = row[x];
        if (ch === "#") {
          if (ready) ctx.drawImage(tile, x * TILE, y * TILE, TILE, TILE);
          else {
            ctx.fillStyle = "#2a3358";
            ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
          }
          ctx.fillStyle = "rgba(239, 230, 214, 0.16)";
          ctx.fillRect(x * TILE, y * TILE, TILE, 3);
        } else if (ch === "=") {
          if (ready) ctx.drawImage(tile, 0, 0, tile.naturalWidth, tile.naturalHeight * 0.35, x * TILE, y * TILE, TILE, 14);
          ctx.fillStyle = "rgba(224, 122, 61, 0.85)";
          ctx.fillRect(x * TILE, y * TILE, TILE, 3);
        } else if (ch === "^" && this.images.spikes.complete) {
          this.blitFoot(ctx, this.images.spikes, x * TILE + TILE / 2, y * TILE + TILE - 2, 54, 243 / 256, 1);
        }
      }
    }

    for (const m of this.level.movers) {
      const pos = this.moverPos(m, this.time);
      if (ready) {
        const tw = TILE;
        for (let x = 0; x < m.w; x += tw) {
          const w = Math.min(tw, m.w - x);
          ctx.drawImage(tile, pos.x + x, pos.y, w, m.h);
        }
      } else {
        ctx.fillStyle = "#3a4678";
        ctx.fillRect(pos.x, pos.y, m.w, m.h);
      }
      ctx.fillStyle = m.axis === "x" ? "#e07a3d" : "#7c5cbf";
      ctx.fillRect(pos.x, pos.y, m.w, 3);
    }

    const orbFrame = this.images.orb[Math.floor(this.time * 8) % 4];
    for (const coin of this.level.coins) {
      if (this.collected.has(coin.id)) continue;
      const bob = Math.sin(this.time * 3 + coin.x) * 3;
      if (orbFrame?.complete) {
        ctx.drawImage(orbFrame, coin.x - 16, coin.y - 16 + bob, 32, 32);
      }
    }

    if (this.images.lantern.complete) {
      for (const cp of this.level.checkpoints) {
        const glow = 0.35 + Math.sin(this.time * 3) * 0.15;
        ctx.fillStyle = `rgba(224, 122, 61, ${glow})`;
        ctx.beginPath();
        ctx.arc(cp.x, cp.y - 36, 18, 0, Math.PI * 2);
        ctx.fill();
        this.blitFoot(ctx, this.images.lantern, cp.x, cp.y - 8, 62, 243 / 256, 1);
      }
    }

    if (this.images.flag.complete) {
      const bob = Math.sin(this.time * 2) * 2;
      this.blitFoot(ctx, this.images.flag, this.level.flag.x, this.level.flag.y + bob, 92, 243 / 256, 1);
    }

    const maskFrame = this.images.mask[Math.floor(this.time * 8) % 4];
    if (maskFrame?.complete) {
      for (const e of this.enemies) {
        this.blitFoot(ctx, maskFrame, e.x + e.w / 2, e.y + e.h + 2, 70, MASK_FOOT, e.dir >= 0 ? 1 : -1);
      }
    }

    this.drawPlayer(ctx);

    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.size, p.size);
      ctx.globalAlpha = 1;
    }
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    let frame: HTMLImageElement;
    if (!this.grounded) {
      if (this.land > 0.08) frame = this.images.jump[3];
      else if (this.vy < -80) frame = this.images.jump[0];
      else if (this.vy < 60) frame = this.images.jump[1];
      else frame = this.images.jump[2];
    } else if (this.land > 0) {
      frame = this.images.jump[3];
    } else if (Math.abs(this.vx) > 30) {
      frame = this.images.run[Math.floor(this.anim * 9) % 4];
    } else {
      frame = this.images.idle[Math.floor(this.anim * 4) % 4];
    }
    if (!frame?.complete || !frame.naturalWidth) {
      ctx.fillStyle = "#efe6d6";
      ctx.fillRect(this.px, this.py, PW, PH);
      return;
    }
    const squash = this.land > 0 ? this.land / 0.12 : 0;
    const footX = this.px + PW / 2;
    const footY = this.py + PH;
    ctx.save();
    ctx.translate(footX, footY);
    ctx.scale(this.facing * (1 + squash * 0.14), 1 - squash * 0.16);
    const drawH = 104;
    const drawW = drawH;
    const top = -drawH * HERO_FOOT;
    ctx.drawImage(frame, -drawW / 2, top, drawW, drawH);
    ctx.restore();
  }

  private blitFoot(
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    footX: number,
    footY: number,
    drawH: number,
    footRatio: number,
    flip: number,
  ) {
    if (!img.complete || !img.naturalWidth) return;
    const drawW = drawH * (img.naturalWidth / img.naturalHeight);
    ctx.save();
    ctx.translate(footX, footY);
    ctx.scale(flip, 1);
    ctx.drawImage(img, -drawW / 2, -drawH * footRatio, drawW, drawH);
    ctx.restore();
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getX: () => number;
      getY: () => number;
      getSpeed: () => number;
      getYaw: () => number;
      setKeys: (codes: string[]) => void;
    };
  }
}
