export const TILE = 40;

export type LevelId = "faroles" | "puente" | "torre";

export type Mover = {
  ox: number;
  oy: number;
  w: number;
  h: number;
  axis: "x" | "y";
  amp: number;
  period: number;
  phase: number;
};

export type Enemy = {
  x: number;
  y: number;
  w: number;
  h: number;
  minX: number;
  maxX: number;
  dir: number;
};

export type Coin = { id: string; x: number; y: number };
export type Spot = { id: string; x: number; y: number };

export type Level = {
  id: LevelId;
  name: string;
  blurb: string;
  grid: string[];
  cols: number;
  rows: number;
  width: number;
  height: number;
  spawn: Spot;
  flag: Spot;
  checkpoints: Spot[];
  coins: Coin[];
  enemies: Enemy[];
  movers: Mover[];
};

export const LEVEL_ORDER: LevelId[] = ["faroles", "puente", "torre"];

function blank(w: number, h: number) {
  return Array.from({ length: h }, () => Array.from({ length: w }, () => "."));
}

function paint(g: string[][], x: number, y: number, w: number, ch: string) {
  for (let i = 0; i < w; i++) {
    if (g[y] && g[y][x + i] !== undefined) g[y][x + i] = ch;
  }
}

function walls(g: string[][]) {
  for (let y = 0; y < g.length; y++) {
    g[y][0] = "#";
    g[y][g[0].length - 1] = "#";
  }
}

function buildFaroles() {
  const W = 72;
  const H = 14;
  const g = blank(W, H);
  walls(g);
  const floors: Array<[number, number]> = [
    [1, 12],
    [22, 16],
    [46, 26],
  ];
  for (const [x, w] of floors) {
    paint(g, x, 10, w, "#");
    paint(g, x, 12, w, "#");
  }
  paint(g, 13, 11, 9, "^");
  paint(g, 38, 11, 8, "^");
  g[9][3] = "P";
  g[9][6] = "C";
  g[9][9] = "C";
  g[9][26] = "H";
  g[9][30] = "C";
  g[9][34] = "C";
  g[9][48] = "K";
  g[9][52] = "C";
  g[9][56] = "C";
  g[9][63] = "C";
  g[9][67] = "F";
  g[9][16] = "M";
  g[9][41] = "M";
  paint(g, 24, 8, 4, "=");
  g[7][25] = "C";
  paint(g, 50, 7, 4, "=");
  g[6][51] = "C";
  paint(g, 28, 5, 3, "#");
  g[4][29] = "C";
  return g;
}

function buildPuente() {
  const W = 86;
  const H = 16;
  const g = blank(W, H);
  walls(g);
  const floors: Array<[number, number]> = [
    [1, 14],
    [24, 18],
    [52, 14],
    [72, 13],
  ];
  for (const [x, w] of floors) {
    paint(g, x, 12, w, "#");
    paint(g, x, 14, w, "#");
  }
  paint(g, 15, 13, 9, "^");
  paint(g, 42, 13, 10, "^");
  paint(g, 66, 13, 6, "^");
  g[11][3] = "P";
  g[11][7] = "C";
  g[11][11] = "C";
  g[11][28] = "H";
  g[11][33] = "C";
  g[11][37] = "C";
  g[11][55] = "K";
  g[11][58] = "C";
  g[11][61] = "H";
  g[11][76] = "C";
  g[11][80] = "F";
  g[11][18] = "M";
  g[11][46] = "M";
  g[10][68] = "V";
  paint(g, 26, 9, 5, "=");
  g[8][28] = "C";
  paint(g, 54, 9, 4, "#");
  g[8][55] = "C";
  paint(g, 74, 8, 4, "=");
  g[7][75] = "C";
  paint(g, 30, 6, 4, "#");
  g[5][31] = "C";
  paint(g, 56, 6, 3, "#");
  g[5][57] = "C";
  return g;
}

function buildTorre() {
  const W = 18;
  const H = 40;
  const g = blank(W, H);
  walls(g);
  paint(g, 1, 37, 16, "#");
  g[36][3] = "P";
  g[36][6] = "C";
  g[36][12] = "H";
  g[36][14] = "C";

  const ledges: Array<{
    y: number;
    x: number;
    w: number;
    coin?: boolean;
    spike?: boolean;
    check?: boolean;
    flag?: boolean;
  }> = [
    { y: 34, x: 1, w: 7, coin: true },
    { y: 31, x: 10, w: 7, coin: true },
    { y: 28, x: 1, w: 8, spike: true, coin: true },
    { y: 25, x: 9, w: 8, coin: true },
    { y: 22, x: 1, w: 8, check: true, coin: true },
    { y: 19, x: 10, w: 7, coin: true },
    { y: 15, x: 1, w: 7, spike: true },
    { y: 12, x: 9, w: 8, coin: true },
    { y: 9, x: 1, w: 7, coin: true },
    { y: 5, x: 8, w: 9, flag: true, coin: true },
  ];

  for (const ledge of ledges) {
    paint(g, ledge.x, ledge.y, ledge.w, "#");
    const air = ledge.y - 1;
    if (ledge.spike) {
      g[air][ledge.x] = "^";
      g[air][ledge.x + 1] = "^";
    }
    if (ledge.coin) {
      const cx = ledge.check ? ledge.x + 5 : ledge.spike ? ledge.x + 4 : ledge.x + 2;
      if (g[air][cx] === ".") g[air][cx] = "C";
    }
    if (ledge.check) g[air][ledge.x + 3] = "K";
    if (ledge.flag) g[air][ledge.x + ledge.w - 3] = "F";
  }

  g[21][9] = "V";
  g[13][5] = "M";
  g[8][9] = "V";
  g[33][8] = "C";
  g[27][6] = "C";
  g[16][4] = "C";
  return g;
}

const RAW: Record<LevelId, { name: string; blurb: string; grid: string[][] }> = {
  faroles: {
    name: "Distrito de la Luna",
    blurb: "Corre, junta monedas y salta las púas.",
    grid: buildFaroles(),
  },
  puente: {
    name: "Puente de Máscaras",
    blurb: "Losas móviles, máscaras blancas y un vacío largo.",
    grid: buildPuente(),
  },
  torre: {
    name: "Torre Blanca",
    blurb: "Trepa con el doble salto hasta la bandera.",
    grid: buildTorre(),
  },
};

function compile(id: LevelId): Level {
  const raw = RAW[id];
  const grid = raw.grid.map((row) => row.join(""));
  const rows = grid.length;
  const cols = grid[0].length;
  for (const row of grid) {
    if (row.length !== cols) throw new Error(`Fila desigual en ${id}`);
  }

  const coins: Coin[] = [];
  const checkpoints: Spot[] = [];
  const enemies: Enemy[] = [];
  const movers: Mover[] = [];
  let spawn: Spot | null = null;
  let flag: Spot | null = null;
  let coinN = 0;
  let cpN = 0;
  let mvN = 0;

  const cell = (x: number, y: number) => grid[y]?.[x] ?? "#";

  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const ch = grid[y][x];
      if (ch === "C") {
        coins.push({
          id: `${id}-c${coinN++}`,
          x: x * TILE + TILE / 2,
          y: y * TILE + TILE / 2,
        });
      } else if (ch === "K") {
        checkpoints.push({
          id: `${id}-k${cpN++}`,
          x: x * TILE + TILE / 2,
          y: (y + 1) * TILE,
        });
      } else if (ch === "P") {
        spawn = { id: "spawn", x: x * TILE + 10, y: (y + 1) * TILE };
      } else if (ch === "F") {
        flag = { id: "flag", x: x * TILE + TILE / 2, y: (y + 1) * TILE };
      } else if (ch === "H") {
        const ew = 34;
        const eh = 36;
        let left = x;
        let right = x;
        while (left > 1 && cell(left - 1, y + 1) === "#") left--;
        while (right < cols - 2 && cell(right + 1, y + 1) === "#") right++;
        const capL = Math.max(left, x - 5);
        const capR = Math.min(right, x + 5);
        const minX = capL * TILE + 6;
        const maxX = (capR + 1) * TILE - ew - 6;
        enemies.push({
          x: Math.min(Math.max(x * TILE, minX), Math.max(minX, maxX)),
          y: (y + 1) * TILE - eh,
          w: ew,
          h: eh,
          minX,
          maxX: Math.max(minX + 8, maxX),
          dir: x > cols / 2 ? -1 : 1,
        });
      } else if (ch === "M" || ch === "V") {
        const wide = ch === "M";
        const pw = wide ? TILE * 2.5 : TILE * 1.8;
        movers.push({
          ox: x * TILE + TILE / 2 - pw / 2,
          oy: y * TILE + 16,
          w: pw,
          h: 16,
          axis: wide ? "x" : "y",
          amp: wide ? 64 : 70,
          period: 3.1 + (mvN % 3) * 0.35,
          phase: mvN * 1.3,
        });
        mvN++;
      }
    }
  }

  if (!spawn || !flag) throw new Error(`Nivel ${id} sin inicio o meta`);

  return {
    id,
    name: raw.name,
    blurb: raw.blurb,
    grid,
    cols,
    rows,
    width: cols * TILE,
    height: rows * TILE,
    spawn,
    flag,
    checkpoints,
    coins,
    enemies,
    movers,
  };
}

export const LEVELS: Level[] = LEVEL_ORDER.map(compile);

export function levelById(id: LevelId) {
  const level = LEVELS.find((entry) => entry.id === id);
  if (!level) throw new Error(id);
  return level;
}
